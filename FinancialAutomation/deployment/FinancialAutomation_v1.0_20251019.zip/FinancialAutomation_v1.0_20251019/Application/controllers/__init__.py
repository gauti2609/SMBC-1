"""__init__ file for controllers package"""

from .auth_controller import AuthController

__all__ = ['AuthController']
