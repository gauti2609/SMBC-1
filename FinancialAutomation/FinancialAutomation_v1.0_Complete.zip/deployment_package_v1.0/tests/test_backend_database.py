"""
Backend Tests for Database Operations

These tests verify backend logic without GUI.
"""

import pytest
from controllers.auth_controller import AuthController
from models.company_info import CompanyInfo
from models.master_data import MajorHead, MinorHead, Grouping
from models.user import User


@pytest.mark.backend
@pytest.mark.database
class TestDatabaseOperations:
    """Test suite for database CRUD operations"""
    
    def test_create_user(self, db_manager):
        """Test user creation"""
        success, message, user_id = AuthController.register_user(
            username='testuser_db',
            password='testpass123',
            email='testdb@example.com',
            full_name='Test DB User'
        )
        
        assert success is True
        assert user_id is not None
    
    def test_create_company(self, db_manager, test_user):
        """Test creating a company"""
        company = CompanyInfo(
            user_id=test_user.user_id,
            entity_name='Database Test Company',
            cin_no='L12345TN2020PLC123456',
            address='123 Test St'
        )
        company.save()
        
        assert company.company_id is not None
        assert company.entity_name == 'Database Test Company'
    
    def test_get_user_companies(self, db_manager, test_user, test_company):
        """Test retrieving all companies for a user"""
        companies = CompanyInfo.get_user_companies(test_user.user_id)
        
        assert len(companies) >= 1
        assert any(c.entity_name == 'Test Company Ltd' for c in companies)
    
    def test_create_major_head(self, db_manager, test_company):
        """Test creating a major head"""
        major_head = MajorHead(
            company_id=test_company.company_id,
            code='A001',
            name='Current Assets',
            head_type='Asset'
        )
        major_head.save()
        
        assert major_head.major_head_id is not None
        assert major_head.name == 'Current Assets'
    
    def test_create_minor_head(self, db_manager, test_company):
        """Test creating a minor head under major head"""
        # Create major head first
        major_head = MajorHead(
            company_id=test_company.company_id,
            code='A001',
            name='Current Assets',
            head_type='Asset'
        )
        major_head.save()
        
        # Create minor head
        minor_head = MinorHead(
            company_id=test_company.company_id,
            major_head_id=major_head.major_head_id,
            code='A001-01',
            name='Cash and Bank',
            head_type='Asset'
        )
        minor_head.save()
        
        assert minor_head.minor_head_id is not None
        assert minor_head.major_head_id == major_head.major_head_id
    
    def test_delete_company(self, db_manager, test_user):
        """Test deleting a company"""
        # Create temporary company
        temp_company = CompanyInfo(
            user_id=test_user.user_id,
            entity_name='Temp Delete Test',
            cin='L12345XX2020PLC999999'
        )
        temp_company.save()
        company_id = temp_company.company_id
        
        # Delete it
        temp_company.delete()
        
        # Verify it's deleted
        deleted = CompanyInfo.get_company_by_id(company_id)
        assert deleted is None
    
    def test_update_company(self, db_manager, test_company):
        """Test updating company information"""
        original_name = test_company.entity_name
        
        # Update name
        test_company.entity_name = 'Updated Test Company'
        test_company.save()
        
        # Reload from database
        reloaded = CompanyInfo.get_company_by_id(test_company.company_id)
        assert reloaded.entity_name == 'Updated Test Company'
        
        # Restore original
        test_company.entity_name = original_name
        test_company.save()


@pytest.mark.backend
class TestBusinessLogic:
    """Test suite for business logic"""
    
    def test_trial_balance_validation(self, db_manager, test_company):
        """Test trial balance debit/credit validation"""
        from models.trial_balance import TrialBalance
        
        # Create balanced trial balance entries
        tb1 = TrialBalance(
            company_id=test_company.company_id,
            ledger_name='Cash',
            debit=100000,
            credit=0
        )
        tb1.save()
        
        tb2 = TrialBalance(
            company_id=test_company.company_id,
            ledger_name='Capital',
            debit=0,
            credit=100000
        )
        tb2.save()
        
        # Get all entries and validate balance
        all_entries = TrialBalance.get_all_by_company(test_company.company_id)
        total_debit = sum(e.debit for e in all_entries)
        total_credit = sum(e.credit for e in all_entries)
        
        assert total_debit == total_credit, "Trial balance should be balanced"
    
    def test_financial_year_validation(self):
        """Test financial year date validation"""
        from datetime import datetime
        
        fy_start = datetime(2024, 4, 1)
        fy_end = datetime(2025, 3, 31)
        
        # Verify FY end is after FY start
        assert fy_end > fy_start
        
        # Verify it's approximately 1 year
        days_diff = (fy_end - fy_start).days
        assert 360 <= days_diff <= 366
